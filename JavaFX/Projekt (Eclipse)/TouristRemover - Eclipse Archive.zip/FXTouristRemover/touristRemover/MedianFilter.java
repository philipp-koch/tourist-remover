package touristRemover;

import java.util.ArrayList;

import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

/* Performs a multivariate median filtering of provided source images. All images must be of identical sizes, and there must be 
 * at least 3 of them for a meaningful result. If this criteria is not met, a modal  error message is shown to the user. 
 * 
 * The filtering is performed in its own thread, updating the parameterized progressbar with the respective state of progress. 
 * During image processing, a button next to the proressbar is shown so that the user can terminate the process. Because of the
 * filtering being performed in its own thread, the GUI stays responsive during the process and is usable (e.g. for zooming, 
 * switching images etc.) 
 * 
 * Once the filtering has been performed successfully, the resulting image gets displayed in the parameterized ImageView.*/
public class MedianFilter {
	ArrayList<Image> pictures;
	WritableImage result;
	
	int pictureWidth;
	int pictureHeight;
	
	ProgressBar progressBar;
	ImageView currentImage;
	Button stopButton;
	Task<Void> imageProcessing;
		
	/* Constructor */
	public MedianFilter(ArrayList<Image> thumbnails, ProgressBar progressbar, ImageView currentImage, Button stopButton) throws Exception {			
		pictures = thumbnails;
		this.progressBar = progressbar;
		this.stopButton = stopButton;
		this.currentImage = currentImage;
		checkPrerequisites();		
	}
		
	/* Performs multivariate median filtering */
	public void performThreadedFiltering() {
		// instantiate background task that is computed in its own thread;
		// see http://docs.oracle.com/javafx/2/threads/jfxpub-threads.htm for more information on concurrency in JavaFX
		imageProcessing = new Task<Void>() {
			@Override public Void call() { 
				result = new WritableImage(pictureWidth, pictureHeight);

				ArrayList<Double> red = new ArrayList<Double>();
				ArrayList<Double> green = new ArrayList<Double>();
				ArrayList<Double> blue = new ArrayList<Double>();

				int pixelsFinished = 0;
				int pixelsTotal = pictureWidth * pictureHeight;

				for (int x=0; x < pictureWidth; x++) {
					for (int y=0; y < pictureHeight; y++) {
						for (int idx=0; idx < pictures.size(); idx++) {
							
							// cancel thread if user has clicked the respective button next to the progressbar 
							if (imageProcessing.isCancelled()) { 
								stopButton.setVisible(false);	// hide stop button
								updateProgress(0, 0); 			// reset progressbar
								return null; 					// quit method immediately 
							}

							// store RGB values at the current pixel position of all images separately
							red.add(pictures.get(idx).getPixelReader().getColor(x, y).getRed());
							green.add(pictures.get(idx).getPixelReader().getColor(x, y).getGreen());
							blue.add(pictures.get(idx).getPixelReader().getColor(x, y).getBlue());					
						}			

						// write median pixel values to resulting image
						Color pixelValue = new Color(getMedianValue(red), getMedianValue(green), getMedianValue(blue), 1.0); // RGB + alpha				
						result.getPixelWriter().setColor(x, y, pixelValue);

						red.clear();
						green.clear();
						blue.clear();

						// update progress bar in GUI
						pixelsFinished++;
						updateProgress(pixelsFinished, pixelsTotal);
					}					
				}
				
				// process finished successfully: GUI clean-up
				stopButton.setVisible(false);	// hide stop button
				updateProgress(0, 0); 			// reset progressbar
				
				return null; // necessary due to the usage of the placeholder class Void as return type
			}
		}; // end: task
		
		// bind GUI's progress bar to thread's progressProperty in order to have the UI reflect the respective current state
		progressBar.progressProperty().bind(imageProcessing.progressProperty());

		// register event handler to display the resulting filtered image in the zoomPane once the thread has ended
		imageProcessing.addEventHandler(WorkerStateEvent.WORKER_STATE_SUCCEEDED, new EventHandler<WorkerStateEvent>() {
			@Override
			public void handle(WorkerStateEvent t) { currentImage.setImage(result); }			
		});

		// show button for process termination and register click handler  
	    stopButton.setVisible(true);
	    stopButton.setOnAction(a -> {
	    	imageProcessing.cancel();
	    	stopButton.setVisible(false);      	    	
	    });
		
		// start a thread to perform the background processing		
		new Thread(imageProcessing).start();	
	}
	
	/* Checks if all images share the same dimension and if at least three images are provided. */
	private void checkPrerequisites() throws Exception {
		if (pictures.size() < 3) { filterNotApplicable(); } // at least 3 images necessary 
		
		pictureWidth = (int) pictures.get(0).getWidth();
		pictureHeight = (int) pictures.get(0).getHeight();
		
		for (int i=1; i<pictures.size(); i++) {
			if (pictures.get(i).getWidth() != pictureWidth) { filterNotApplicable(); }
			if (pictures.get(i).getHeight() != pictureHeight) { filterNotApplicable(); }
		}		
	}
	
	/* Throws exception if provided images are not suitable for filtering. */
	private void filterNotApplicable() throws Exception {
		throw new Exception("Illegal image properties. Filter cannot be applied.");
	}
	
	/* Returns the median of given numbers. */
	private Double getMedianValue(ArrayList<Double> input) {
		input.sort(null); // sort using 'natural order', i.e. numerically ascending
		
		// even number of elements
		if (input.size() % 2 == 0) {			
			double leftValue = input.get((input.size() / 2) -1); // zero-based indices! E.g. 4 elements --> [.*..]
			double rightValue = input.get(input.size() / 2);	 // ...and 									[..*.]
			
			return (leftValue + rightValue) / 2; 
		}
		
		// odd number of elements
		return input.get((int) Math.floor(input.size() / 2)); // e.g. 5 elements --> floor(5/2) = 2 (zero-based!) [..*..]
	}		
}