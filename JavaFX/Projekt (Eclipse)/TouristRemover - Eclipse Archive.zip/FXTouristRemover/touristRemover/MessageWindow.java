package touristRemover;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class MessageWindow {
	
	public static void show(String windowTitle, String headline, String message) {		
		Alert infoWindow = new Alert(AlertType.ERROR);
		infoWindow.setTitle(windowTitle);
		infoWindow.setHeaderText(headline);
		infoWindow.setContentText(message);

		infoWindow.showAndWait(); // show modally
	}	
}