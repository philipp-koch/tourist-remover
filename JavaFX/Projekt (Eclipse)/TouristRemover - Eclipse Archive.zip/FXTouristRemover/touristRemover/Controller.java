package touristRemover;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.SplitPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

/* Controller class: Manages program logic */
public class Controller implements Initializable{

	// The @FXML annotation enables the FXMLLoader instance to inject values defined in the FXML file into references in this controller class;
	// mandatory for private objects, can be omitted if object is public, but it's good practice to always use them
	
	// MainWindow: containers and controls	
	@FXML private MenuBar menuBar;
	@FXML private ProgressBar prg_numberCrunching;
	@FXML private Button btn_stopProcess;
	@FXML private Slider sld_zoomSlider;
	@FXML private Label lbl_zoomLevel;
	@FXML private SplitPane splitpane;
	@FXML private ScrollPane zoomPane;
	@FXML private ScrollPane thumbsPane;
	@FXML private VBox vbox;
	@FXML private ImageView currentImage;
	@FXML private Group imageContainer;
	
	// MainWindow: menubar items
	@FXML private MenuItem MenuFileCloseImage;
	@FXML private MenuItem MenuFileSaveImageAs;
	@FXML private MenuItem MenuView100Percent;
	@FXML private MenuItem MenuViewFitInWindow;
	@FXML private MenuItem MenuViewZoomIn;
	@FXML private MenuItem MenuViewZoomOut;
	@FXML private CheckMenuItem MenuViewShowSidebar;
	@FXML private MenuItem MenuFilterMultivariateMedianFilter;
	
	// MainWindow: contextmenu items:
	@FXML private MenuItem ContextmenuView100Percent;
	@FXML private MenuItem ContextmenuViewFitInWindow;
	@FXML private MenuItem ContextmenuFileSaveImageAs;
	@FXML private MenuItem ContextmenuFileCloseImage;
	@FXML private CheckMenuItem ContextmenuViewShowSidebar;	
	
	// locally used properties	
	ArrayList<File> loadedImageFiles = new ArrayList<File>(); // used for image duplicates avoidance
	DoubleProperty zoomProperty = new SimpleDoubleProperty();
	final Double ZOOM_MIN = 0.02;	// i.e. 2%
	final Double ZOOM_MAX = 4.0;	// i.e. 400%
	double lastDividerPosition;
	
	/* (3) Initializes nodes of the window instantiated in step 2 at Main.start(). */ 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	System.out.println("[Controller.initialize] has been called."); // TODO remove debug

		// declare globally used zoom level and initialize as 100%; add a change listener so that whenever
		// its value changes, both the displayed image and the zoomSlider value get updated accordingly		
		zoomProperty.addListener(z -> zoomPropertyChanged(zoomProperty));		
		zoomProperty.set(1.0); // set initial zoom value (calls listener zoomPropertyChanged)				
	
	    // initialize zoom slider and register listener to apply slider position changes as new zoom level		
		sld_zoomSlider.setMin(ZOOM_MIN);
	    sld_zoomSlider.setMax(ZOOM_MAX);
	    sld_zoomSlider.valueProperty().addListener((slider, oldValue, newValue)	// onValueChange: 
	    		-> zoomProperty.set((double) newValue) 							// update global zoomLevel		    
	    );  
	    
	    // enable mouse wheel zoom
	    zoomPane.addEventFilter(ScrollEvent.ANY, e -> {
	    	double zoomChange = 1;
	    	if (e.getDeltaY() > 0) { zoomChange = 1.1; } 			// zoom in
	    	else if (e.getDeltaY() < 0) { zoomChange = 1 / 1.1; }	// zoom out
	    	
	    	zoomProperty.set(zoomProperty.get() * zoomChange);    	// apply zoom change
	    	e.consume(); // prevent mouse-wheel event from being processed any further (e.g. scrolling the image)	    	
	    });

	    // center displayed zoomPane image on window resize	    
	    zoomPane.widthProperty().addListener((wp, oldWidth, newWidth) -> { centerImageHorizontally(newWidth); });
	    zoomPane.heightProperty().addListener((hp, oldHeight, newHeight) -> { centerImageVertically(newHeight); });
	    
	    
	    // once the displayed image has changed, change its size so that it fits into the viewport
	    currentImage.imageProperty().addListener((o, oldValue, newValue) -> {    	
	    	if (newValue != null) { fitImageInViewport(); }
	    	sld_zoomSlider.setDisable(newValue == null); // en-/disable zoom slider	
	    	lbl_zoomLevel.setVisible(newValue != null);	 // only show zoom level if image is displayed
	    });
	    
	    // synchronize selection status of both menubar and contextmenu items "show sidebar" via bidirectional property binding
	    MenuViewShowSidebar.selectedProperty().bindBidirectional(ContextmenuViewShowSidebar.selectedProperty());
	}  
   
    /* Centers the image horizontally in the zoomPane. Gets called on zoomPane.WidthChange. */
    private void centerImageHorizontally(Number viewportWidth) {
    	if (currentImage.getImage() != null) {
			if (currentImage.getImage().getWidth() * zoomProperty.get() < (double) viewportWidth) { // viewport is wider than image (i.e. horizontal gaps)
    		imageContainer.setTranslateX((zoomPane.getWidth() - currentImage.getImage().getWidth() * zoomProperty.get()) / 2);			
			} else { // image is wider than viewport, ...
				imageContainer.setTranslateX(0); // ... so there must not be any horizontal gap
			}
    	}
    }    

    /* Centers the image vertically in the zoomPane. Gets called on zoomPane.HeightChange. */
    private void centerImageVertically(Number viewportHeight) {
    	if (currentImage.getImage() != null) {
			if (currentImage.getImage().getHeight() * zoomProperty.get() < (double) viewportHeight) {
				imageContainer.setTranslateY((zoomPane.getHeight() - currentImage.getImage().getHeight() * zoomProperty.get()) / 2);
			} else { // image is taller than viewport, ...
				imageContainer.setTranslateY(0); // ... so there must not be any vertical gap
			}				
    	}
    }
    
    /* Event handler for zoomProperty.ValueChange. */
    public void zoomPropertyChanged(DoubleProperty newZoom) {
    	// ensure zoom level doesn't exceed defined maximum value or fall below minimum value
    	if (newZoom.get() > ZOOM_MAX) { newZoom.set(ZOOM_MAX); }
    	if (newZoom.get() < ZOOM_MIN) { newZoom.set(ZOOM_MIN); }
    	zoomProperty.set(newZoom.get());
    	
    	sld_zoomSlider.setValue(newZoom.get()); 						// update zoomSlider position 
    	lbl_zoomLevel.setText((Math.round(newZoom.get() * 100)) + "%"); // update zoomLevel label   	
    	if (currentImage.getImage() != null) {
    		currentImage.setScaleX(newZoom.get());
    		currentImage.setScaleY(newZoom.get());    		
    		centerImageHorizontally(zoomPane.getWidth());
    		centerImageVertically(zoomPane.getHeight());
    	}
    }
        
    /* Opens a (multiple) file(s) selection dialog. Triggered via menu or keyboard shortcut. */
    public void loadPictures() {
    	FileChooser filechooser = new FileChooser();
    	List<File> chosenFiles;
    	
    	// declare file type filters
    	filechooser.getExtensionFilters().addAll(
    			new FileChooser.ExtensionFilter("Alle Bilder", "*.jpg;*.png"),
    			new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png"));                
    	
    	
    	// have user select one or multiple image files
    	chosenFiles = filechooser.showOpenMultipleDialog(menuBar.getScene().getWindow()); 
    	
    	// add new Thumbnails if they haven't already been added sometime earlier
    	if (chosenFiles != null) {    		
    		for (int i=0; i < chosenFiles.size(); i++) {
    	    	if (!loadedImageFiles.contains(chosenFiles.get(i))) {	// avoid duplicates
    	    		loadedImageFiles.add(chosenFiles.get(i));			// keep track of image filepath    	    		
    	    		Thumbnail thumb = new Thumbnail(chosenFiles.get(i).getAbsolutePath(), thumbsPane, vbox, currentImage);
    	    		vbox.getChildren().add(thumb);     					// add Thumbnail to GUI
    	    	}    			
    		}
    		
    		// select Thumbnail representing the first loaded image (and thus display it)
    		Thumbnail.get(0).setSelected(); 
    	}
    }
    
    /* Opens a save file dialog where the user can store the currently displayed image on disk. */
    public void savePicture() {
    	FileChooser filechooser = new FileChooser();
    	File chosenFile;
    	
    	// declare file type filters
    	filechooser.getExtensionFilters().addAll(
    			new FileChooser.ExtensionFilter("Alle Bilder", "*.jpg;*.png"),
    			new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png"));
    	
    	// have user select one or multiple image files
    	chosenFile = filechooser.showSaveDialog(menuBar.getScene().getWindow()); 	
    	
    	if (chosenFile != null) {
    		// determine desired image format
    		String format;
    		switch ((String) chosenFile.getName().subSequence(chosenFile.getName().length() -4, chosenFile.getName().length())) {
    		case ".jpg":
    		case "jpeg":
    			format = "jpg";	
    			break;

    		case ".png":
    			format = "png";
    			break;

    		default:
    			format = "jpg";   		
    		}

    		// save image under the user specified location
    		BufferedImage bimage = SwingFXUtils.fromFXImage(currentImage.getImage(), null);    		
    		// remove alpha-channel from buffered image; necessary work-around due to alpha channel bug
    		// (see http://stackoverflow.com/questions/19548363/image-saved-in-javafx-as-jpg-is-pink-toned):
    		BufferedImage imageRGB = new BufferedImage(bimage.getWidth(), bimage.getHeight(), BufferedImage.OPAQUE);
    		Graphics2D graphics = imageRGB.createGraphics();
    		graphics.drawImage(bimage, 0, 0, null);
    		graphics.dispose(); // free up memory
    		
    		try {
				ImageIO.write(imageRGB, format, chosenFile);
			} catch (IOException e) {
				MessageWindow.show(	"Fehler!", 
									"Das Bild konnte nicht gespeichert werden.",
									"Es ist ein Fehler aufgetreten: " + e.getLocalizedMessage());
			}
    	}   	
    }   
    
    /* Increases zoom. Helper method so that the zoom-in menu entry can be assigned directly via FXML. */
    public void increaseZoomLevel() { 
    	zoomProperty.set(zoomProperty.get() +0.01);
    }
    
    /* Decreases zoom. Helper method so that the zoom-out menu entry can be assigned directly via FXML. */
    public void decreaseZoomLevel() { 
    	zoomProperty.set(zoomProperty.get() -0.01);
    }
    
    /* Sets zoom to 100%. Helper method so that the respective menu entry can be assigned directly via FXML. */
    public void setZoomLevelTo100percent() { 
    	zoomProperty.set(1.0);    	
    }
    
    /* Shows or hides the Thumbnails bar. Helper method so that the respective menu entry can be assigned directly via FXML. */
    public void toggleSidebar() {    	
    	// hide sidebar
    	if (!MenuViewShowSidebar.isSelected()) {
    		thumbsPane.setMinWidth(0);
    		thumbsPane.setMaxWidth(0);
    		lastDividerPosition = splitpane.getDividerPositions()[0]; // remember current position for restoring it later 
    		splitpane.setDividerPositions(1.0);
    	
    	// show sidebar 
    	} else {
    		thumbsPane.setMinWidth(85);
    		thumbsPane.setMaxWidth(350);
    		splitpane.setDividerPositions(lastDividerPosition);	// restore position before the divider was hidden
    	}    	
    }
    
    /* Adjusts image size so that it fits into the viewport. Helper method so that the respective menu entry can be assigned directly via FXML. */
    public void fitImageInViewport() {    	
    	double viewportWidth = zoomPane.getWidth();
    	double viewportHeight = zoomPane.getHeight();
    	double imageWidth = currentImage.getImage().getWidth();
    	double imageHeight = currentImage.getImage().getHeight();
    	double suitableZoomLevel = Math.min(viewportHeight / imageHeight, viewportWidth / imageWidth);
    	
    	zoomProperty.set(suitableZoomLevel);
    	centerImageHorizontally(viewportWidth);
    	centerImageVertically(viewportHeight);
    }
    
    /* Activates menu items if suitable. Gets called prior to when a menu is shown and also when using accelerator keys of certain 
     * entries to access the respective menu item. */
    public void toggleMenuItemAvailability() {
    	// en-/disables (Context-)Menu items depending on if there is an image being displayed in the zoomPane or not
    	MenuFileCloseImage.setDisable(currentImage.getImage() == null);  		// Menubar: ~ "close image"
    	ContextmenuFileCloseImage.setDisable(currentImage.getImage() == null);  // Contextmenu: ~ "close image"
    	MenuFileSaveImageAs.setDisable(currentImage.getImage() == null); 		// Menubar: ~ "save as"
    	ContextmenuFileSaveImageAs.setDisable(currentImage.getImage() == null); // Contextmenu: ~ "save as"
    	MenuView100Percent.setDisable(currentImage.getImage() == null);  		// Menubar: ~ "set zoom to 100%"
    	ContextmenuView100Percent.setDisable(currentImage.getImage() == null);  // Contextmenu: ~ "set zoom to 100%"
    	MenuViewFitInWindow.setDisable(currentImage.getImage() == null); 		// Menubar: ~ "fit in window"
    	ContextmenuViewFitInWindow.setDisable(currentImage.getImage() == null); // Contextmenu: ~ "fit in window"
    	MenuViewZoomIn.setDisable(currentImage.getImage() == null); 	 		// Menubar: ~ "zoom in"
    	MenuViewZoomOut.setDisable(currentImage.getImage() == null); 	 		// Menubar: ~ "zoom out"
    	
    	// disables Menubar: ~ "median filter" as long as not at least 3 images have been loaded
    	MenuFilterMultivariateMedianFilter.setDisable(Thumbnail.getInstancesTotal() < 3);
    }      
    
    /* Removes currently displayed zoomPane image and its Thumbnail. Helper method so that the respective menu entry can be 
     * assigned directly via FXML. */
    public void removeCurrentZoomPaneImage() {
    	Thumbnail.remove(currentImage.getImage()); // also removes the corresponding zoomPane image    	    	
    }      
    
    /* Performs multivariate median filter on all currently loaded images and displays the result. */
    public void performMedianFilter() {   		
    	try { 	
    		// perform Median filtering: The calculation is done in its own thread. Once finished, the result gets displayed in the zoomPane.
    		MedianFilter medianfilter = new MedianFilter(Thumbnail.getAllImages(), prg_numberCrunching, currentImage, btn_stopProcess);
    		medianfilter.performThreadedFiltering();
    		
    	} catch (Exception e) {
    		// filtering not possible: Show error to the user
    		MessageWindow.show("Fehler", 
    				"Der Filter kann nicht angewandt werden.", 
    				"Es m�ssen mindestens drei Bilder vorhanden sein, und s�mtliche Bilder m�ssen die gleiche Dimension (H�he und Breite) aufweisen.");
    	}
    }
}