package touristRemover;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application {	
		
	/* (1) program entry point */
	public static void main(String[] args) {
		System.out.println("[Main.main] has been called."); // TODO remove debug				
		launch(args);																				// call launcher (which then calls start)
	}

	/* (2) initializes root window and displays it */
	@Override
	public void start(Stage primaryStage) {
		try {
			System.out.println("[Main.start] has been called."); // TODO remove	debug					 
			
			// MainWindow
			Parent root = FXMLLoader.load(getClass().getResource("MainWindowSplit.fxml"));			// get FXML (i.e. structural layout definition); also
																									// calls Controller.initialize() to inject values	
			System.out.println("FXML has been loaded."); // TODO remove debug
			
			Scene scene = new Scene(root, 700, 500);												// instantiate scene graph (i.e. content of window)
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());	// get CSS (i.e. additional visual style definition)
			
			primaryStage.setMinWidth(700);
			primaryStage.setMinHeight(500);
			primaryStage.setScene(scene);															// instantiate stage (i.e. the window frame)
			
			// display main window
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}