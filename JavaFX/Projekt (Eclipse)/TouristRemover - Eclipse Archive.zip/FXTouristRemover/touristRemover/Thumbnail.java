package touristRemover;

import java.util.ArrayList;

import javafx.geometry.Pos;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/* A Thumbnail is a custom styled HBox wrapping an ImageView, handling mouse click actions. 
 * Selections (via left mouse click) are treated exclusively, i.e. in a radio-button-like manner. */
public class Thumbnail extends HBox {
	
	// data management
	private String imagePath;
	private ImageView imageview;
	ContextMenu contextmenu;
	
	// instance management
	private static ArrayList<Thumbnail> instances = new ArrayList<Thumbnail>();	
	private Boolean selected = false;
	private ScrollPane parentScrollPane;
	private VBox thumbnailsContainerInParent;
	private ImageView currentlyShownZoomableImage;
	
	// style
	private double borderWidth = 1; 						// px
	private double horizontalPadding = 12; 					// px; space between left/right thumbnail border and parent pane border
	private CornerRadii cornerradii = new CornerRadii(10);	// amount of px the corners are to be rounded
	Color borderColor = new Color(.5, .5, .5, 1.0);			// RGBa
	Color backgroundColor = new Color(.9, .9, .9, 1.0);		// RGBa
	
	/* Constructor */
	public Thumbnail(String imagePath, ScrollPane parentScrollpane, VBox thumbnailContainer, ImageView currentImage) {
		this.parentScrollPane = parentScrollpane;
		this.thumbnailsContainerInParent = thumbnailContainer;
		this.currentlyShownZoomableImage = currentImage;
		this.imagePath = imagePath;
	
		loadImage(); 			// load image from parameterized path into ImageView
		stylize(); 				// define layout of the Thumbnail (alignment, borders etc.)
		declareBindings();		// make Thumbnail auto-sizing
		createContextMenu();	// shows up if Thumbnail is right-clicked
		registerClickHandler();	// handle left- and right-clicks
		instances.add(this);	// keep track of this instance internally				
	}
	
	/** INITIALIZATION **/	
	/* Opens image file parameterized via Constructor and assigns its content to the ImageView. */
	private void loadImage() {		
		imageview = new ImageView(new Image("file:" + imagePath));
		imageview.setPreserveRatio(true);
	}	
				
	/* Defines the Thumbnail's layout in the GUI. */
	private void stylize() {
    	// initialize HBox
    	this.getChildren().add(imageview);
    	this.alignmentProperty().set(Pos.CENTER);
		
		// define background
    	BackgroundFill fill = new BackgroundFill(backgroundColor, cornerradii, null);
		Background back = new Background(fill);
		this.setBackground(back);
		
		// define borders
		BorderStroke stroke = new BorderStroke (borderColor, BorderStrokeStyle.SOLID, cornerradii, new BorderWidths(borderWidth));    		
		Border border = new Border(stroke);
		this.setBorder(border);	
	}
	
	/* Declares property bindings for automatic, dynamic Thumbnail size calculation. */
	private void declareBindings() {		
		this.prefWidthProperty().bind(parentScrollPane.widthProperty()
				.subtract(2 * borderWidth).subtract((2 * horizontalPadding)));
		this.prefHeightProperty().bind(parentScrollPane.widthProperty()
				.subtract(2 * borderWidth).subtract((2 * horizontalPadding))); // also bound to width -->  square shape!
		imageview.fitWidthProperty().bind(this.prefWidthProperty());
		imageview.fitHeightProperty().bind(this.prefWidthProperty()); // also bound to width --> square shape!
	}
	
	/* Initiates context menu. */
	private void createContextMenu() {				
		contextmenu = new ContextMenu();
		MenuItem ContextRemoveImage = new MenuItem();
		
		ContextRemoveImage.setText("Bild entfernen"); 		// menu item text		
		ContextRemoveImage.setOnAction(a -> remove(this)); 	// register action hander
		contextmenu.getItems().add(ContextRemoveImage);		
	}
	
	 /* Registers moue click handler. */
    private void registerClickHandler() {
    	this.setOnMouseClicked(e -> {    		
    		if (e.getButton() == MouseButton.PRIMARY ) { 				// left mouse-click:		
    			this.setSelected(); 									// update which Thumbnail is currently selected...
    			showRepresentedImageInZoomPane();						// ...and display its image in the zoomPane
    		    		
    		} else if (e.getButton() == MouseButton.SECONDARY) {		// right mouse-click
    			contextmenu.show(this, e.getScreenX(), e.getScreenY()); // display context menu    			
    		}
    	});  
    }   
	
	/** INTERACTION: by instance **/	
	/* Returns the assigned image in full resolution. */
	public Image getImage() {
		return imageview.getImage();
	}
	
	/* Returns the assigned image's path. */
	public String getImagePath() {
		return imagePath;
	}
	
	/* Returns the number of Thumbnails currently instantiated. */
	public static int getInstancesTotal() {
		return instances.size();
	}
	
	/* Returns the thumbnail's index number. Used for handling selections. */
	public int getIndex() {
		return instances.indexOf(this);
	}
	
	/* Returns the Thumbnail's context menu object. */
	public ContextMenu getContextMenu() {
		return contextmenu;
	}

	/* Sets Thumbnail status to "selected" and unselects all other instances. */
	public void setSelected() {
		this.selected = true;
		this.setEffect(null);
		showRepresentedImageInZoomPane();
				
		for (Thumbnail t : instances) { 
			if (!t.equals(this)) { 
				t.selected = false;
				t.setEffect(new ColorAdjust(0, -.85, 0, 0)); // desaturate almost completely, i.e. simulate "high-key image"
			}
		}		
	}
	
	/* Displays the image represented by a Thumbnail in the zoomPane. */
	private void showRepresentedImageInZoomPane() {
		currentlyShownZoomableImage.setImage(this.getImage());
	}	
	
	/* Removes the currently selected Thumbnail. Called via right-click handler. */
	private void remove(Thumbnail t) {
		// if Thumbnail-to-be-deleted represents the current zoomPane image, remove that as well 
		ImageView i = currentlyShownZoomableImage;		
		if (i.getImage() != null && i.getImage().equals(t.getImage())) { i.setImage(null); }
		
		int idx = instances.indexOf(t);
		
		instances.remove(t); // delete instance from internal ArrayList
		thumbnailsContainerInParent.getChildren().remove(t); // delete Thumbnail node in GUI
		
		// select another Thumbnail close by if possible:			
		if (Thumbnail.getInstancesTotal() > 0) {
			if (Thumbnail.getInstancesTotal() -1 >=idx) {
				instances.get(idx).setSelected();					
			} else if (Thumbnail.getInstancesTotal() -1 == idx -1) {
				instances.get(idx -1).setSelected();								
			}		
		}
	}
		
	/** INTERACTION: public static methods **/
	/* Returns an ArrayList<Image> containing all currently loaded images. */
	public static ArrayList<Image> getAllImages() {
		ArrayList<Image> images = new ArrayList<Image>();
		for (Thumbnail t : instances) { images.add(t.getImage()); }			
		
		return images;
	}

	/* Returns a reference of the Thumbnail with the parameterized index number. */
	public static Thumbnail get(int index) {
		return instances.get(index);
	}
	
	/* Removes Thumbnail representing the parameterized image. */
	public static void remove(Image image) {
		if (image != null) {
			// find Thumbnail instance representing the image
			int i = 0;
			while (!instances.get(i).getImage().equals(image)) { i++; }		

			// remove it
			instances.get(i).remove(instances.get(i));			
		}
	}	
}